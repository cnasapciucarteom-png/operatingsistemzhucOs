; =====================================================================
; Драйвер PS/2 клавиатуры и мыши для Жук.OS (Ассемблер NASM, 32-бит)
; =====================================================================

bits 32

; Порты ввода-вывода контроллера 8042
KB_DATA_PORT    equ 0x60
KB_STATUS_PORT  equ 0x64
KB_CMD_PORT     equ 0x64

section .data
    ; Переменные состояния мыши
    global mouse_x
    global mouse_y
    mouse_x      dw 160         ; Начальная координата X (центр экрана VGA 320x200)
    mouse_y      dw 100         ; Начальная координата Y
    mouse_b      db 0           ; Состояние кнопок мыши

    ; Внутренний буфер пакета мыши (3 байта)
    mouse_packet times 3 db 0
    mouse_offset db 0

section .text

; --- 1. ИНИЦИАЛИЗАЦИЯ PS/2 МЫШИ И КЛАВИАТУРЫ ---
global ps2_init
ps2_init:
    push eax

    ; Ждем свободного буфера ввода контроллера
.wait1:
    in al, KB_STATUS_PORT
    test al, 2
    jnz .wait1

    ; Отправляем команду включения вспомогательного порта мыши
    mov al, 0xA8
    out KB_CMD_PORT, al

    ; Читаем байт конфигурации контроллера
.wait2:
    in al, KB_STATUS_PORT
    test al, 2
    jnz .wait2
    mov al, 0x20
    out KB_CMD_PORT, al

.wait3:
    in al, KB_STATUS_PORT
    test al, 1
    jz .wait3
    in al, KB_DATA_PORT
    
    ; Включаем прерывания от клавиатуры (бит 0) и мыши (бит 1)
    or al, 0x03  
    push eax

.wait4:
    in al, KB_STATUS_PORT
    test al, 2
    jnz .wait4
    mov al, 0x60
    out KB_CMD_PORT, al

.wait5:
    in al, KB_STATUS_PORT
    test al, 2
    jnz .wait5
    pop eax
    out KB_DATA_PORT, al

    ; Устанавливаем настройки по умолчанию для мыши (Set Defaults - 0xF6)
    call mouse_send_cmd
    db 0xF6

    ; Включаем отправку данных мыши (Data Reporting - 0xF4)
    call mouse_send_cmd
    db 0xF4

    pop eax
    ret

; Вспомогательная функция отправки команды конкретно мыши
mouse_send_cmd:
    pop dword [temp_ret]
    mov al, [temp_ret]
    mov bl, al          ; Сохраняем команду
    
    ; Сигнализируем контроллеру, что следующий байт для мыши (0xD4)
    call .w_in
    mov al, 0xD4
    out KB_CMD_PORT, al
    
    ; Отправляем саму команду
    call .w_in
    mov al, bl
    out KB_DATA_PORT, al
    
    ; Ждем подтверждения ACK (0xFA)
    call .w_out
    in al, KB_DATA_PORT
    
    jmp [temp_ret]      ; Возврат (команда передавалась прямо из потока вызова)
.w_in:
    in al, KB_STATUS_PORT
    test al, 2
    jnz .w_in
    ret
.w_out:
    in al, KB_STATUS_PORT
    test al, 1
    jz .w_out
    ret

section .bss
    temp_ret resd 1


; --- 2. ОБРАБОТЧИК ПРЕРЫВАНИЯ КЛАВИАТУРЫ (IRQ1) ---
global keyboard_handler_asm
keyboard_handler_asm:
    push eax
    
    in al, KB_DATA_PORT   ; Считываем скан-код из порта клавиатуры (0x60)
    ; TODO: Сохраните скан-код в кольцевой буфер клавиатуры Жук.OS

    ; Отправка сигнала End of Interrupt (EOI) ведущему PIC
    mov al, 0x20
    out 0x20, al
    
    pop eax
    iret


; --- 3. ОБРАБОТЧИК ПРЕРЫВАНИЯ МЫШИ (IRQ12) ---
global mouse_handler_asm
mouse_handler_asm:
    push eax
    push ebx
    push ecx

    in al, KB_DATA_PORT   ; Читаем байт данных мыши из порта 0x60

    movzx ecx, byte [mouse_offset]
    
    ; Синхронизация: первый байт пакета мыши всегда имеет бит 3 установленным (0x08)
    cmp ecx, 0
    jne .store_byte
    test al, 0x08
    jz .done              ; Если синхронизация сбилась, сбрасываем

.store_byte:
    mov ebx, mouse_packet
    mov [ebx + ecx], al
    inc ecx
    mov [mouse_offset], cl

    cmp ecx, 3
    jl .done              ; Ждем, пока соберутся все 3 байта пакета

    ; --- Пакет из 3 байт собран: [Флаги, dX, dY] ---
    movzx eax, byte [mouse_packet + 1] ; Смещение по X
    movzx ebx, byte [mouse_packet + 2] ; Смещение по Y

    ; Обработка знака X (бит 4 флагов)
    test byte [mouse_packet], 0x10
    jz .pos_x
    or eax, 0xFFFFFF00    ; Расширение знака до отрицательного числа в 32-бит
.pos_x:
    add [mouse_x], ax     ; Прибавляем к координате X
; Обработка знака Y (бит 5 флагов)
    test byte [mouse_packet], 0x20
    jz .pos_y
    or ebx, 0xFFFFFF00
.pos_y:
    ; В PS/2 оси Y инвертированы (движение вверх уменьшает значение на физическом датчике)
    sub [mouse_y], bx     ; Вычитаем, чтобы движение вверх поднимало курсор на экране

    ; Ограничения экрана под VGA 13h (320x200)
    mov ax, [mouse_x]
    cmp ax, 0
    jge .check_xmax
    mov word [mouse_x], 0
    jmp .check_ymin
.check_xmax:
    cmp ax, 319
    jle .check_ymin
    mov word [mouse_x], 319

.check_ymin:
    mov ax, [mouse_y]
    cmp ax, 0
    jge .check_ymax
    mov word [mouse_y], 0
    jmp .reset_pkg
.check_ymax:
    cmp ax, 199
    jle .reset_pkg
    mov word [mouse_y], 199

.reset_pkg:
    mov byte [mouse_offset], 0  ; Сбрасываем смещение для следующего пакета

.done:
    ; Отправка EOI ведомому (IRQ12) и ведущему PIC
    mov al, 0x20
    out 0xA0, al
    out 0x20, al

    pop ecx
    pop ebx
    pop eax
    iret