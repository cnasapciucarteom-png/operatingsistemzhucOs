[org 0x7C00]

    mov [BOOT_DRIVE], dl      ; Сохраняем номер загрузочного диска
    mov bp, 0x9000            ; Настраиваем стек
    mov sp, bp

    call load_kernel          ; Читаем ядро с диска

    cli                       ; Запрещаем прерывания
    lgdt [gdt_descriptor]     ; Загружаем GDT

    mov eax, cr0
    or eax, 0x00000001        ; Включаем Protected Mode
    mov cr0, eax

    jmp 0x08:init_pm          ; Прыжок в защищенный режим (0x08 — селектор кода)

load_kernel:
    mov bx, 0x1000            ; Адрес загрузки ядра в память
    mov dh, 4                 ; Количество секторов
    mov dl, [BOOT_DRIVE]      ; Диск
    
    mov ah, 0x02              ; Чтение секторов BIOS
    mov al, dh                
    mov ch, 0x00              
    mov dh, 0x00              
    mov cl, 0x02              ; Начинаем со 2-го сектора
    int 0x13                  
    jc disk_error             
    ret

disk_error:
    jmp $

[BITS 32]
init_pm:
    mov ax, 0x10              ; 0x10 — селектор данных в нашей GDT
    mov ds, ax
    mov ss, ax
    mov es, ax
    mov fs, ax
    mov gs, ax

    mov esp, 0x90000

    ; Передаем управление ядру, загруженному по адресу 0x1000
    jmp 0x1000

; --- Таблица GDT ---
gdt_start:
    dq 0x0                    ; Нулевой дескриптор

gdt_code:
    dw 0xFFFF
    dw 0x0
    db 0x0
    db 10011010b
    db 11001111b
    db 0x0

gdt_data:
    dw 0xFFFF
    dw 0x0
    db 0x0
    db 10010010b
    db 11001111b
    db 0x0

gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1
    dd gdt_start

BOOT_DRIVE db 0

times 510-($-$$) db 0
dw 0xAA55