@echo off
cls

echo Building desktop module for Zhuk.OS...
"C:\Program Files\NASM\nasm.exe" -f bin desktop.asm -o desktop.com

echo Desktop build complete!
pause