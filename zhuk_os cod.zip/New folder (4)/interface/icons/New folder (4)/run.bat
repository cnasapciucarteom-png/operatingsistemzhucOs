@echo off
cd /d "C:\Users\c\Downloads\WinSetupFromUSB-1-10\files\tools\RMPrepUSB\QEMU"
qemu.exe -L . -drive format=raw,file="%~dp0os.bin"