[org 0x1000]
[bits 32]

_start:
    ; Прямая запись символа 'Z' (от Жук.OS) в самый верхний левый угол экрана
    mov edx, 0xb8000
    mov byte [edx], 'Z'       ; Сам символ
    mov byte [edx+1], 0x1F    ; Белый символ на синем фоне (чтобы точно было ярко видно)

    ; Вывод остальной строки
    mov edi, 0xb8002          ; Начинаем со следующей позиции
    mov esi, msg
    mov ah, 0x0f              ; Белый текст на черном

.print_loop:
    lodsb
    test al, al
    jz .hang
    mov [edi], al
    mov [edi+1], ah
    add edi, 2
    jmp .print_loop

.hang:
    cli
    hlt
    jmp .hang

msg db 'huk.OS 32-bit Kernel Loaded!', 0