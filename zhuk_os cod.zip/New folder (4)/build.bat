@echo off
echo Building bootloader...
"C:\Program Files\NASM\nasm.exe" -f bin boot.asm -o boot.bin

echo Building kernel...
"C:\Program Files\NASM\nasm.exe" -f bin kernel.asm -o kernel.bin

echo Building FAT12 driver...
"C:\Program Files\NASM\nasm.exe" -f bin drivers\fat12.asm -o drivers\fat12.bin

echo Building PS/2 keyboard & mouse driver...
"C:\Program Files\NASM\nasm.exe" -f bin drivers\Ps2.asm -o drivers\Ps2.bin

echo Combining system binaries into os.bin...
copy /b boot.bin + kernel.bin + drivers\fat12.bin + drivers\Ps2.bin os.bin

echo Preparing assets...
if not exist build_disk mkdir build_disk
copy interface\icons\*.bmp build_disk\ >nul 2>&1

echo Creating floppy image via PowerShell...
powershell -Command "Copy-Item os.bin -Destination floppy.img -Force"

echo Build and image creation complete successfully!
pause